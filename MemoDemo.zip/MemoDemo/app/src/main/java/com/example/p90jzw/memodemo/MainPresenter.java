package com.example.p90jzw.memodemo;

public class MainPresenter implements MainContract.Presenter {
    @Override
    public void setView() {

    }
}
