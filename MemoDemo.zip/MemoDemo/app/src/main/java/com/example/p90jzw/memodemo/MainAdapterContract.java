package com.example.p90jzw.memodemo;

public interface MainAdapterContract {
    interface View{

    }
    interface Model {

    }
}
